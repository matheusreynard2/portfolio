package com.apiestudar.api_prodify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiEstudarApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiEstudarApplication.class, args);
	}

}
